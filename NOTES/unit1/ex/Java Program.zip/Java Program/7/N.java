package p;

public class N
{
	public static int i=100;
}

