package my;

public class A
{
static final int i=13;
public static void printP()
	{
	System.out.println("Class A New");
	}
}
