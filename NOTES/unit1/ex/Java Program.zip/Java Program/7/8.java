//import p.M;

class ABC
{
	public static void main(String s[])
	{
	
	System.out.println(p.M.iVal);
	System.out.println(new p.M().getJ());
	System.out.println(new p.M().getK());
	System.out.println(new p.M().getL());
	}
}