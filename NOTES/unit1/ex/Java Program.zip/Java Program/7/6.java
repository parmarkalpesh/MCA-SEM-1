import static A.*;

class ABC
{
	public static void main(String s[])
	{
	System.out.println(i);
	}
}