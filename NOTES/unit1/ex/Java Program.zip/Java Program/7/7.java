package p;

public class M
{
	public static int iVal=5;
}