import p.N;
class T
{
public static void main(String s[])
	{
	System.out.println(N.i);
	}
}