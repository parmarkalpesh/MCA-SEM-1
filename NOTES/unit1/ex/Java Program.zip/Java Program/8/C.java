public class C
{
	static class D
	{
	static int j=50;
	}
}

class A 
{
	public static void main(String s[])
	{
	A a=new A();
	Class p = A.class.getClasses();
	System.out.println(p.getName());
	
	
	}
class M
	{
	}
}

