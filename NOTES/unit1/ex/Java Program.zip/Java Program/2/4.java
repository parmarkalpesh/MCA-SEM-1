class C1
{

	public static void main(String args[])
	{
	System.out.println(Integer.SIZE);
	System.out.println(Byte.SIZE);
	D1 d=new D1();
	System.out.println(d.p);
	}
}