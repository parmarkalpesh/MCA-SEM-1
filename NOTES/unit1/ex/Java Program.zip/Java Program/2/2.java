
class test
{
public static void main(String args[])
	{
	Integer i = new Integer(10);
	float p=3;
	System.out.println(Byte.SIZE);
	}
}