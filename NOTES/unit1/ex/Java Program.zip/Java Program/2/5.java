
class D1
{
public int i=20;
}
