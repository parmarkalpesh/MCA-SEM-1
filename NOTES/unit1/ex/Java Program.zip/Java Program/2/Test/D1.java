
class D1
{
	int i=20;
	D1(){}
}
