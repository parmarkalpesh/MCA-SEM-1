import java.io.*;
class Kapil
{
public static PrintStream shukla = new PrintStream(System.out);
}
class Txt
{
public static void main(String args[])
	{
	Kapil.shukla.println("Hello World");
	}
}