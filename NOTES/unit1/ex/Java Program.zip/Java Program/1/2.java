class Cemo
{
int p=10;
}
class Temo
{
public static void main(String []args)
	{
	 int a[][]={{1,2},{3,4}};
         System.out.println(a[0][0]+" "+a[1][1]);
	   //System.out.println(Memo.p);
	}
}